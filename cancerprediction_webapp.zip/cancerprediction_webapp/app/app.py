import streamlit as st
import pickle
import pandas as pd


#loading the saved trained model
loaded_model=p.load(open('C:\Users\GOKUL RAJ\OneDrive\Documents\RAJ\projects\streamlit projects\cancerprediction_webapp\app\breastcancermodel.pkl','rb'))


if __name__ == '__main__':
    main()
# Add a title
st.set_page_config(page_title="Breast Cancer Diagnosis",
                    page_icon="👩‍⚕️", 
                    layout="wide", 
                    initial_sidebar_state="expanded")
# Add a header
st.title("Breast Cancer Diagnosis")