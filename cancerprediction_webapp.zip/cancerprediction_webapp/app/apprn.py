import streamlit as st
import joblib
import numpy as np

# Load model and scaler
#C:/Users/GOKUL RAJ/OneDrive/Documents/RAJ/projects/streamlit projects/cancerprediction_webapp/app/breastcancermodel.pkl
#C:/Users/GOKUL RAJ/OneDrive/Documents/RAJ/projects/streamlit projects/cancerprediction_webapp/app/scaler.pkl
model = joblib.load('C:/Users/GOKUL RAJ/OneDrive/Documents/RAJ/projects/streamlit projects/cancerprediction_webapp/app/breastcancermodel.pkl')
scaler = joblib.load('C:/Users/GOKUL RAJ/OneDrive/Documents/RAJ/projects/streamlit projects/cancerprediction_webapp/app/scaler.pkl')

# Define prediction function
def predict(features):
    features_scaled = scaler.transform([features])
    prediction = model.predict(features_scaled)
    return prediction


# Add a title
st.set_page_config(page_title="Breast Cancer Diagnosis",
                    page_icon="👩‍⚕️", 
                    layout="wide", 
                    initial_sidebar_state="expanded")

# Streamlit user interface
st.title('Breast Cancer Prediction')

mean_radius = st.number_input('Mean Radius', min_value=0.0, max_value=50.0, value=14.0)
mean_texture = st.number_input('Mean Texture', min_value=0.0, max_value=50.0, value=20.0)
mean_perimeter = st.number_input('Mean Perimeter', min_value=0.0, max_value=200.0, value=90.0)
mean_area = st.number_input('Mean Area', min_value=0.0, max_value=3000.0, value=600.0)
mean_smoothness = st.number_input('Mean Smoothness', min_value=0.0, max_value=1.0, value=0.1)

# Add more inputs for all features as needed...

if st.button('Predict'):
    features = [
        mean_radius, mean_texture, mean_perimeter, mean_area, mean_smoothness,
        # Add more features here...
    ]
    prediction = predict(features)
    diagnosis = 'Malignant' if prediction[0] == 1 else 'Benign'
    st.write(f'The predicted diagnosis is: {diagnosis}')
